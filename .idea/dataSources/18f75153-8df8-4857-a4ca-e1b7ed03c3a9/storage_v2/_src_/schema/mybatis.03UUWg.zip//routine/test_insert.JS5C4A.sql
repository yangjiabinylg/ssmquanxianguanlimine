CREATE PROCEDURE test_insert()
  BEGIN
    DECLARE i INT DEFAULT 6;
    START TRANSACTION;
    WHILE i<100
    DO
      INSERT INTO role(roleName,roleCode,valid,orders) VALUES ( '角色'+i, 'role'+i, i, i);

      SET i=i+1;
    END WHILE;
    COMMIT;
  END;

